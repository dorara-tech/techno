# <a style="font-family:cursive">MySPAMBot-OTP WORK 1000% FOR ID NUMBER!!</a>
<p align="justify">Anda punya masalah sama bocil di komen? Atau Anda sedang adu bacot sama fans club bola sebelah? <b>MySPAMBot-OTP</b> solusinya!! <b>MySPAMBot-OTP</b> adalah sebuah aplikasi prank yang menggunakan sebuah BOT untuk melakukan requests berulang kali sehingga target akan dikirimi pesan OTP bertubi-tubi. Aplikasi ini ditujukan sebagai bahan belajar (Open Source) menggunakan modul Requests dan implementasi HTTPS tools di Python.</p>
<br>

# Testimoni 😂😂
Terdapat Error Handling sehingga ketika di-running bot tetap dapat terus berjalan walaupun ditinggal tidur. 
<p align="center">
    <br>
    <a>
        <img src="https://telegra.ph/file/6a51a8a9776c4d36a406e.png">
    </a><br>
    Korban 1<br> <br>
    <a>
        <img src="https://telegra.ph/file/517f5077ff6ec3b8da592.png">
        <img src="https://telegra.ph/file/164309a8ba0868fcce538.png">
    </a><br>
    WhatsApp dan SMS    
</p>
<br>


## Video Tutorial 🚀
**`Coming Soon`**

<br>


# v.1.0.9 (**3 November 2023**) WORK! ✔️✔️
<p align="center">
    <a>
        <img src="https://telegra.ph/file/9a0918ad39ddc8efd986e.png">
    </a><br>
    Target: <b>Provider IM3</b> 
</p>
<br>

# Instalasi
Sudah pasti require <b>[Python](https://www.python.org/downloads/)</b> , install <b>[Python](https://www.python.org/downloads/)</b> terlebih dahulu: <b>[Click Disini](https://www.python.org/downloads/)</b>

<br>

### <p style="color:red">NOTE: Instalasi Dengan GIT</p> Jika kamu Programmer yang memiliki [GIT](https://git-scm.com/downloads) maka,

- **Buka CMD / Command Prompt (atau terminal VSCode)**

- **Clone repository**
```bash
git clone https://github.com/rickyfazaa/MySPAMBot-OTP
```
- **Masuk kedalam directory**
```sh
cd MySPAMBot-OTP
```
- **Jalankan main.py atau Ketik ini di Terminal ( CMD )**
```bash
python main.py
```
<br>

### <p style="color:red">NOTE: Instalasi Tanpa GIT</p> Jika kamu **TIDAK** memiliki [GIT](https://git-scm.com/downloads) maka,
- **Download Manual:**
[Download MySPAMBot-OTP](https://github.com/rickyfazaa/MySPAMBot-OTP/releases/download/v.1.0.9/MySPAMBot-OTP-v1.0.9-windows.rar) <br>
- Extract **MySPAMBot-OTP-v1.0.9-windows.rar**
- **Buka CMD / Command Prompt (atau terminal VSCode)**
- **Ketik ini untuk masuk kedalam Folder MySPAMBot-OTP**
```sh
cd MySPAMBot-OTP
```
- **Jalankan main.py atau Ketik ini di Terminal ( CMD )**
```bash
python main.py
```
<br>

## Dependencies 🚀
**`Coming Soon`**
<br>

<br>


## Support Me 
## (KALO ANDA SUKA JANGAN LUPA STAR NYA OK, BIAR GK KETINGGALAN UPDATE YGY)
### [**My Instagram: @rickyfazaa**](https://www.instagram.com/rickyfazaa)    
Untuk bertanya perihal tools bisa langsung dm [**Instagram**](https://www.instagram.com/rickyfazaa).
