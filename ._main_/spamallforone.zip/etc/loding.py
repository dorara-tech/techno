import os, sys, threading

from warn.warn import *

def loding():

    print (f"{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}{kin}•{kon}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}•{kon}•{kin}")

