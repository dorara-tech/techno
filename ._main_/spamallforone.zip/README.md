# Spam Brutal All For One
SPAM BRUTAL SMS, CALL, WA

Tutorial:
<pre><code>
apt update && apt upgrade
pkg update
pkg install python
git clone https://github.com/AbilSeno/spamallforone
cd spamallforone
pip install -r harus.txt
python brutal.py
>>> Pilih 1
>>> Masukkan no telepon
>>> Selesai
</code></pre>
