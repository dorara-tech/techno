# Index-Spam
<p align="center">
<img src="https://img.shields.io/static/v1?label=Author&color=green&message=./AmmarExploit &logo=Acclaim&logoColor=white&style=for-the-badge"><br>
Tools Spam Sms,Call,Wa Spesial Tahun baru (+62) only,
Yang recode gw doain tangannya buntung !
Kalo recode ijin dulu bangke
https://t.me/SariiRooti
</p>
<p align="center">
  <a href="https://github.com/AmmarrBN"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=Minimal+Kasi+Star+lah+kontol+!" alt="UwU">
</p>

# Info
<p align="center">
  <a href="https://github.com/AmmarrBN"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=Sewaktu+waktu+tools+ini+akan" alt="UwU">
  <a href="https://github.com/AmmarrBN"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=expired+jadi+gunakan+dengan+bijak+!" alt="UwU">
</p>

<details open>
  <summary><strong> Install Package + Run Script (AmmarrBN)</strong></summary>

  ```bash
  pkg update && pkg upgrade
  pkg install python
  pkg install git
  pkg install python2
  git clone https://github.com/AmmarrBN/Index-SpamV2
  cd Index-SpamV2
  pip install -r requirements.txt
  python main.py
  ```
  </details>
