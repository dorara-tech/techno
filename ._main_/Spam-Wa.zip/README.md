# Script SpamWa

- Untuk tutorial lebih lanjut silahkan kunjungi blog: https://www.foruminformasi.com/search/label/Termux?&max-results=6

- $ pkg install python
- $ pkg install git
- $ python3 -m pip install requests
- $ git clone https://github.com/Bilal-Andrian/Spam-Wa
- $ cd Spam-Wa
- $ python3 spam.py

Sekian terimakasih

